#Kriptografija v1.0
#ova datoteka sadrži definicije funkcija koje koristimo za
#šifriranje i kriptoanalizu

#šifrira jedan znak rotacijskom, tj. cezarovom šifrom
def rotirajZnak(znak,pomak):
    abeceda="ABCČĆDĐEFGHIJKLMNOPRSŠTUVZŽ"
    if znak in abeceda:
        rotirano = abeceda[(abeceda.index(znak)+pomak)%len(abeceda)]
    else:
        rotirano = znak
    return rotirano

#računa frekvencije pojavljivanja znakova u tekstu i vraća ih kao listu
#verzija kao na što smo radili na satu
def frekvencijeZnakova(tekst):
    abeceda="ABCČĆDĐEFGHIJKLMNOPRSŠTUVZŽ"
    brojZnakova=[0 for znak in abeceda]
    ukupnoZnakova=0
    for znak in tekst:
        if znak in abeceda:
            brojZnakova[abeceda.index(znak)] +=1
            ukupnoZnakova += 1
    frekvencije = [brojZnakova[i]/ukupnoZnakova for i in range(len(abeceda))]
    return frekvencije

#računa frekvencije pojavljivanja znakova u tekstu i vraća ih kao listu
#verzija malo drugačija od one na satu
#koristi metodu count() koja radi na stringovima
def frekvencijeZnakova2(tekst):
    abeceda="ABCČĆDĐEFGHIJKLMNOPRSŠTUVZŽ"
    brojZnakova=[]
    ukupnoZnakova=0
    for znak in abeceda:
        brojZnakova.append(tekst.count(znak))
        ukupnoZnakova += brojZnakova[abeceda.index(znak)]
    frekvencije = [brojZnakova[i]/ukupnoZnakova for i in range(len(abeceda))]
    return frekvencije

#pomakne prvu komponentu vektora tako da dođe na zadnje mjesto
#vektor je zapisan u obliku liste
def rotirajVektor(vektor):
    vektor.append(vektor.pop(0))
    return vektor

#računa skalarni produkt 2 jednako dugačka vektora
#vektori se prihvaćaju u obliku liste
def skalarniProdukt(vek1,vek2):
    produkt = 0
    for i in range(len(vek1)):
        produkt += vek1[i]*vek2[i]
    return produkt
