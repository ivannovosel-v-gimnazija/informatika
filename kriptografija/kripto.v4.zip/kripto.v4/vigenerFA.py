from kriptografija import frekvencijeZnakova,rotirajZnak,koincidencije,rotirajVektor,skalarniProdukt

#otvaramo datoteku sa dosta teksta na ciljanom jeziku
#ovo radimo kako bi zračunali tablicu frekvencija ako nije poznato unaprijed
with open(r"C:\Users\nemoh\Desktop\kripto\probni tekst na hrvatskom.txt","r",encoding="utf-8") as datoteka:
    tekst = datoteka.read().upper()
#normalna frekvencija hrvatskog jezika
vektorAbecede = frekvencijeZnakova(tekst)

#duljina ključa
#za vigenereovu šifru prvo moramo naći kolika je duljina ključa
with open(r"C:\Users\nemoh\Desktop\kripto\izlazna.txt","r",encoding="utf-8") as datoteka:
    tekst = datoteka.read().upper()

#za sad koristi ljudsku pamet, ali trebalo bi napraviti kod koji to
#radi automatski
print("Raspodjela koincidencija: nađi duljinu ključa: \n")
print(koincidencije(tekst))
duljina = int(input("Koliko je ključ dugačak?"))

#frekvencije pojedinih dijelova teksta
#znamo da je svaki N-ti znak imao isti pomak gdje je N = duljina ključa
#za svaki od dijelova teksta radi se odvojena frekvencijska analiza
#i računaju se svi pomaci
pomaci = []
for i in range(duljina):
    podtekst = ""
    for j in range(i,len(tekst),duljina):
        podtekst += tekst[j]
    vektorŠifre = frekvencijeZnakova(podtekst)
    produkti = []
    for član in vektorŠifre:
        produkti.append(skalarniProdukt(vektorŠifre,vektorAbecede))
        vektorŠifre = rotirajVektor(vektorŠifre)
    pomaci.append(produkti.index(max(produkti)))

#dešifriranje - prolazimo kroz tekst i redom primjenjujemo pomake
dešifrirano = ""
for i in range(len(tekst)):
    dešifrirano += rotirajZnak(tekst[i],-pomaci[i%len(pomaci)])

with open(r"C:\Users\nemoh\Desktop\kripto\dekriptirano.txt","w",encoding="utf-8") as datoteka:
    datoteka.write(dešifrirano+"\n")