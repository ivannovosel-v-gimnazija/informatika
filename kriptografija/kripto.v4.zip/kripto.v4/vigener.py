#program kriptira tekst vigenerovom šifrom
#korisnik utipkava ključ, a originalni tekst se nalazi u ulazna.txt
from kriptografija import rotirajZnak, počistiVišak
abeceda = "ABCČĆDĐEFGHIJKLMNOPRSŠTUVZŽ"

#otvaramo datoteku sa tekstom koji želimo šifrirati
with open(r"C:\Users\nemoh\Desktop\kripto\ulazna.txt","r",encoding="utf-8") as datoteka:
    tekst = datoteka.read().upper()
    tekst = počistiVišak(tekst,abeceda)

#trebalo bi dodati provjeru je li ključ zapravo u redu!
ključ = input("Utipkaj ključnu riječ za šifriranje (samo slova HR abecede):").upper()

#šifriranje
šifriranitekst = ""
for i in range(len(tekst)):
    pomak = abeceda.index(ključ[i%len(ključ)])
    šifriranitekst += rotirajZnak(tekst[i],pomak)

#radimo novu datoteku u koju će se spremiti šifrirani tekst
with open(r"C:\Users\nemoh\Desktop\kripto\izlazna.txt","w",encoding="utf-8") as datoteka:
    datoteka.write(šifriranitekst)