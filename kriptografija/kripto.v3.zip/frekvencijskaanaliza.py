from kriptografija import frekvencijeZnakova,zamijeniZnak

#otvaramo datoteku sa dosta teksta na ciljanom jeziku
#ovo radimo kako bi zračunali tablicu frekvencija ako nije poznato unaprijed
with open(r"C:\Users\nemoh\Desktop\kripto\probni tekst na hrvatskom.txt","r",encoding="utf-8") as datoteka:
    tekst = datoteka.read().upper()
#normalna frekvencija hrvatskog jezika
vektorAbecede = frekvencijeZnakova(tekst)

#otvaramo datoteku sa šifriranim tekstom
with open(r"C:\Users\nemoh\Desktop\kripto\kriptirano.txt","r",encoding="utf-8") as datoteka:
    tekst = datoteka.read().upper()
#frekvencija znakova u šifriranom tekstu
vektorŠifre = frekvencijeZnakova(tekst)

#za sortiranje po frekvenciji
def poFrekvenciji(vektor):
    return vektor[1]
vektorAbecede.sort(key = poFrekvenciji, reverse=True)
vektorŠifre.sort(key = poFrekvenciji, reverse=True)

#sad napravimo tablicu supstitucije, ako se vektori poklapaju
#onda će se na istim indeksima nalaziti slova koja su prebačena
#jedna u drugo
tablica = {vektorŠifre[i][0]:vektorAbecede[i][0] for i in range(len(vektorAbecede))}

#pustimo korisnika da mijenja stvari, malo ljudske inteligencije
while True:
    dešifrirani = ""
    broj = int(input("Koliko znakova dekriptirane poruke želiš vidjeti:"))
    if broj >= len(tekst):
        broj = len(tekst)-1
    for znak in tekst[0:broj]:
        dešifrirani += zamijeniZnak(znak,tablica)
    print(dešifrirani)
    kraj = input("Izgleda li dekriptirano? d/n: ").lower()
    if kraj == 'd':
        break
    prvi = input("Koji znak želiš zamijeniti: ").upper()
    drugi = input("S kojim znakom ga mijenjaš: ").upper()
    prvi = list(tablica.keys())[list(tablica.values()).index(prvi)]
    drugi = list(tablica.keys())[list(tablica.values()).index(drugi)]
    tablica[prvi],tablica[drugi] = tablica[drugi],tablica[prvi]

#kad je gotovo dešifriraj sve
dešifrirani = ""
for znak in tekst:
    dešifrirani += zamijeniZnak(znak,tablica)

#radimo novu datoteku u koju će se spremiti dešifrirani tekst
with open(r"C:\Users\nemoh\Desktop\kripto\dekriptirano.txt","w",encoding="utf-8") as datoteka:
    datoteka.write(dešifrirani)